FUNDO ENGINE — Netlify edition (NO Blaze, NO bank card, NO laptop)
==================================================================
This does exactly what the cloud functions would have done, but it runs
on Netlify's free tier instead — and Netlify never asks for a card.

  bank SMS -> your Sketchware app POSTs it to your Netlify engine
  -> engine reads the amount -> matches the pending request
  -> approves in one safe transaction -> user credited in seconds
  -> user + your admin devices notified
Works 24/7 with your panel closed and your phone asleep.

You need: the iPad or phone browser, ~20 minutes, three free accounts you
probably already have (Google/GitHub/Netlify).

---------------------------------------------------------------
PART A — PUT THE ENGINE FILES ON GITHUB (10 min)
---------------------------------------------------------------
1. Unzip FUNDO-Engine-Netlify.zip on your iPad (Files app -> tap zip).
   You get a folder with 3 files:
     netlify/functions/engine.js   <- the brain
     package.json
     netlify.toml

2. github.com -> sign up free (or sign in) -> top-right "+" -> New repository
   -> name it: fundo-engine -> keep Public -> tick "Add a README file" ->
   Create repository.

3. In the repo, tap "Add file" -> "Create new file".
   In the "Name your file" box type exactly:
       netlify/functions/engine.js
   Open the unzipped engine.js on your iPad (Files app -> long-press ->
   Open in a text editor / Quick Look, select all, copy), paste it into
   the GitHub text area, scroll down, "Commit changes".

4. Repeat "Add file -> Create new file" twice more:
       package.json      (paste the package.json contents)
       netlify.toml      (paste the netlify.toml contents)
   (Public repo is safe: no secrets live in these files.)

---------------------------------------------------------------
PART B — DEPLOY TO NETLIFY (5 min)
---------------------------------------------------------------
5. netlify.com -> sign up FREE choosing "Sign up with GitHub".
   -> "Add new site" -> "Import an existing project" -> GitHub ->
   pick "fundo-engine" -> Deploy site (leave build settings as they are —
   Netlify detects everything itself). Wait for "Deploy successful".

6. Connect the engine to your Firebase:
   a) In another tab: console.firebase.google.com -> your project ->
      gear icon (Project settings) -> "Service accounts" tab ->
      "Generate new private key" -> Confirm. A .json file downloads.
   b) Netlify tab -> your site -> "Site configuration" -> "Environment
      variables" -> "Add a variable":
        Key:   FIREBASE_SERVICE_ACCOUNT
        Value: open the downloaded .json (Files app), copy its ENTIRE
               contents, paste here.
      -> "Add a variable" again:
        Key:   HOOK_KEY
        Value: a long random password you invent (letters + numbers).
               This is the password your Sketchware app will send.
   c) Netlify -> "Deploys" -> "Trigger deploy" -> "Deploy site"
      (this restarts the engine with the new variables).

7. Your engine address is:
       https://YOUR-SITE.netlify.app/.netlify/functions/engine
   (YOUR-SITE is shown at the top of your Netlify site page.)

---------------------------------------------------------------
PART C — CONNECT SKETCHWARE (5 min)
---------------------------------------------------------------
In your Sketchware forwarder, beside the Telegram block, add an
HttpRequest component:
  Method:  POST
  URL:     https://YOUR-SITE.netlify.app/.netlify/functions/engine
  Headers: Content-Type: application/json
           x-autopilot-key: <the HOOK_KEY you invented>
  Body:    {"sms": "<your SMS text variable>"}

Then add a Timer that runs every 2-5 minutes with a second HttpRequest:
  Method:  GET
  URL:     https://YOUR-SITE.netlify.app/.netlify/functions/engine?sweep=1
  Headers: x-autopilot-key: <same HOOK_KEY>
This keeps the withdrawal autopilot running and auto-declines unpaid
requests after the window you set in the admin panel -> Autopilot.

---------------------------------------------------------------
TEST IT
---------------------------------------------------------------
1. A user places an FND order (don't pay yet).
2. Transfer exactly that amount to your bank.
3. Within ~15 seconds the user is credited and you get a push:
   "Autopilot approved FND order".
4. Admin panel -> Autopilot shows the alert and the approval.

TROUBLE SHOOTING
---------------------------------------------------------------
- Netlify function logs: Netlify site -> "Functions" -> engine ->
  "logs" — errors appear there.
- "unauthorised": the x-autopilot-key doesn't match HOOK_KEY.
- "FIREBASE_SERVICE_ACCOUNT env var is missing": redo Part B step 6
  and then Trigger deploy again.
- Keep the downloaded .json private — anyone holding it controls your
  database. It lives only in Netlify's environment variables; never
  paste it into chats, Sketchware screenshots, or GitHub.
